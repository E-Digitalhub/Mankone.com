---
layout: layout.njk
title: Blog
---

<h1>Blog Posts</h1>
<ul>
  {% for post in collections.post reversed %}
    <li>
      <a href="{{ post.url }}">{{ post.data.title }}</a><br/>
      <small>By {{ post.data.author }} – {{ post.date | readableDate }}</small>
    </li>
  {% endfor %}
</ul>