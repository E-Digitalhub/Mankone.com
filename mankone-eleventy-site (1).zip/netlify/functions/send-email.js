const sgMail = require('@sendgrid/mail');
require('dotenv').config();

exports.handler = async function(event, context) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  const { name, email, message } = JSON.parse(event.body);
  if (!name || !email || !message) {
    return { statusCode: 400, body: 'All fields are required' };
  }

  sgMail.setApiKey(process.env.SENDGRID_API_KEY);

  const msg = {
    to: 'evansik70@gmail.com',
    from: 'no-reply@mankone.com',
    subject: `New Contact Form Message from ${name}`,
    text: `Name: ${name}\nEmail: ${email}\nMessage:\n${message}`,
  };

  try {
    await sgMail.send(msg);
    return { statusCode: 200, body: 'Message sent successfully!' };
  } catch (err) {
    console.error(err);
    return { statusCode: 500, body: 'Failed to send message' };
  }
};
