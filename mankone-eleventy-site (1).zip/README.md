# Mankone Eleventy Blog Site

This is a dynamic blog built using [Eleventy (11ty)](https://www.11ty.dev/) with Netlify CMS for easy content management.

## Features
- Dynamic blog index from `_posts/`
- Clean article layout and styles
- Editable via Netlify CMS at `/admin`
- Ready to deploy on Netlify

## Quick Start
1. Install Eleventy
```
npm install -g @11ty/eleventy
```

2. Run Locally
```
npx eleventy --serve
```

3. Deploy to Netlify and connect to GitHub

### 🌐 Deploy Status

[![Netlify Status](https://api.netlify.com/api/v1/badges/YOUR-SITE-ID/deploy-status)](https://app.netlify.com/sites/YOUR-SITE-NAME/deploys)

---

### 📧 Newsletter Integration (Placeholder)

Want to build a subscriber list? You can:
- Embed a Mailchimp or ConvertKit form
- Use Netlify Forms or Functions to collect emails

📥 Example form:
```html
<form name="newsletter" method="POST" data-netlify="true">
  <input type="email" name="email" placeholder="Enter your email" required />
  <button type="submit">Subscribe</button>
</form>
```
