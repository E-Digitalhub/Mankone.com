---
title: "The Discipline of Starting"
date: 2025-08-01
author: Evans Mankone
---

Many people wait until they feel ready. But winners don't wait. They start.

## 1. Feelings follow action

Don't wait for motivation. Start moving — and motivation will follow.

## 2. Start small

Start with 5 minutes. Start with 1 step. Start with now.

> “Do not despise the day of small beginnings.” – Zechariah 4:10
