---
title: "Learning to Lead Yourself"
date: 2025-08-02
author: Evans Mankone
---

Before you lead others, learn to lead yourself.

- Wake yourself up
- Set your own deadlines
- Keep your promises to yourself

This is how leaders are born.
