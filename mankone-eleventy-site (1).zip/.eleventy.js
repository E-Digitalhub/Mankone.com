require("dotenv").config();

module.exports = function(eleventyConfig) {
  eleventyConfig.addPassthroughCopy("css");
  eleventyConfig.addPassthroughCopy("admin");

  eleventyConfig.addFilter("readableDate", dateObj =>
    new Intl.DateTimeFormat("en", { dateStyle: "long" }).format(dateObj)
  );

  console.log("Google Analytics ID:", process.env.GA_TRACKING_ID);

  return {
    dir: {
      input: ".",
      includes: "_includes"
    }
  };
};
